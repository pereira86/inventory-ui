"""Restaurant inventory MVP package."""
